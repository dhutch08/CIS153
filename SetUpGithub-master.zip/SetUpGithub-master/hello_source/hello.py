def hello_message():
    return "Hello, CIS 189!"


if __name__ == '__main__':
    hello_message()
